#include "RemoteControlServer.h"

int main() {
	RemoteControlServer server = RemoteControlServer();
}